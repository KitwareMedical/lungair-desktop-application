class ResidualUnit(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  dimensions : int
  in_channels : int
  out_channels : int
  conv : __torch__.torch.nn.modules.container.Sequential
  residual : __torch__.torch.nn.modules.conv.Conv2d
  def forward(self: __torch__.monai.networks.blocks.convolutions.ResidualUnit,
    x: Tensor) -> Tensor:
    residual = self.residual
    res = (residual).forward(x, )
    conv = self.conv
    cx = (conv).forward(x, )
    return torch.add(cx, res)
class Convolution(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : NoneType
  dimensions : int
  in_channels : int
  out_channels : int
  is_transposed : bool
  conv : __torch__.torch.nn.modules.conv.Conv2d
  adn : __torch__.monai.networks.blocks.acti_norm.ADN
  def forward(self: __torch__.monai.networks.blocks.convolutions.Convolution,
    input: Tensor) -> Tensor:
    conv = self.conv
    adn = self.adn
    input0 = (conv).forward(input, )
    return (adn).forward(input0, )
  def __len__(self: __torch__.monai.networks.blocks.convolutions.Convolution) -> int:
    return 2
