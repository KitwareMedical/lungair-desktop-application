class Sequential(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : NoneType
  unit0 : __torch__.monai.networks.blocks.convolutions.Convolution
  unit1 : __torch__.monai.networks.blocks.convolutions.___torch_mangle_1.Convolution
  def forward(self: __torch__.torch.nn.modules.container.Sequential,
    input: Tensor) -> Tensor:
    unit0 = self.unit0
    unit1 = self.unit1
    input0 = (unit0).forward(input, )
    return (unit1).forward(input0, )
  def __len__(self: __torch__.torch.nn.modules.container.Sequential) -> int:
    return 2
