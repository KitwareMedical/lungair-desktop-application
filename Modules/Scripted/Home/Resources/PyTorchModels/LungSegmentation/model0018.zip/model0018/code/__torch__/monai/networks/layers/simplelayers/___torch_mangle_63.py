class SkipConnection(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  dim : int
  mode : str
  submodule : __torch__.torch.nn.modules.container.___torch_mangle_62.Sequential
  def forward(self: __torch__.monai.networks.layers.simplelayers.___torch_mangle_63.SkipConnection,
    x: Tensor) -> Tensor:
    _0 = uninitialized(Tensor)
    submodule = self.submodule
    y = (submodule).forward(x, )
    mode = self.mode
    if torch.eq(mode, "cat"):
      _2 = [x, y]
      dim = self.dim
      _1 = torch.cat(_2, dim)
    else:
      mode0 = self.mode
      if torch.eq(mode0, "add"):
        _3 = torch.add(x, y)
      else:
        mode1 = self.mode
        if torch.eq(mode1, "mul"):
          _4 = torch.mul(x, y)
        else:
          mode2 = self.mode
          _5 = torch.format("Unsupported mode {}.", mode2)
          ops.prim.RaiseException(_5, "builtins.NotImplementedError")
          _4 = _0
        _3 = _4
      _1 = _3
    return _1
