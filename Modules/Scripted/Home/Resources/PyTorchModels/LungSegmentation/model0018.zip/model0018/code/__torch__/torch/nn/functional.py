def instance_norm(input: Tensor,
    running_mean: Optional[Tensor]=None,
    running_var: Optional[Tensor]=None,
    weight: Optional[Tensor]=None,
    bias: Optional[Tensor]=None,
    use_input_stats: bool=True,
    momentum: float=0.10000000000000001,
    eps: float=1.0000000000000001e-05) -> Tensor:
  _0 = __torch__.torch.nn.functional._verify_spatial_size
  if use_input_stats:
    _1 = _0(torch.size(input), )
  else:
    pass
  _2 = torch.instance_norm(input, weight, bias, running_mean, running_var, use_input_stats, momentum, eps, True)
  return _2
def dropout(input: Tensor,
    p: float=0.5,
    training: bool=True,
    inplace: bool=False) -> Tensor:
  _3 = "dropout probability has to be between 0 and 1, but got {}"
  if torch.lt(p, 0.):
    _4 = True
  else:
    _4 = torch.gt(p, 1.)
  if _4:
    ops.prim.RaiseException(torch.format(_3, p), "builtins.ValueError")
  else:
    pass
  if inplace:
    _5 = torch.dropout_(input, p, training)
  else:
    _5 = torch.dropout(input, p, training)
  return _5
def _verify_spatial_size(size: List[int]) -> NoneType:
  _6 = "Expected more than 1 spatial element when training, got input size {}"
  _7 = torch.__range_length(2, torch.len(size), 1)
  size_prods = 1
  for _8 in range(_7):
    i = torch.__derive_index(_8, 2, 1)
    size_prods = torch.mul(size_prods, size[i])
  if torch.eq(size_prods, 1):
    ops.prim.RaiseException(torch.format(_6, size), "builtins.ValueError")
  else:
    pass
  return None
